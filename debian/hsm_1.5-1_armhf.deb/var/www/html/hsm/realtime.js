var collectedData = JSON.parse('{"all": [[0.0, 0]]}');
